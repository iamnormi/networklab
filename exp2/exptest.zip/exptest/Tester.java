import java.io.*;
import java.net.*;

public class Tester {
   public static void main(String args[]) throws IOException {
      download("http://www.google.com");
   }
   public static void download(String urlString) throws IOException {
      URL url = new URL(urlString);
      try(
         BufferedReader reader = new BufferedReader(new InputStreamReader(url.openStream()));
         BufferedWriter writer = new BufferedWriter(new FileWriter("page.html"));
      ) {
         String line;
         while ((line = reader.readLine()) != null) {
            writer.write(line);
            System.out.println(line);
         }
         System.out.println("Page downloaded.");
         }
      }
   }
}
